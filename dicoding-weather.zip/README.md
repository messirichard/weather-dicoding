aplikasi ini bisa dijalankan di 
https://weather-dicoding-2.now.sh/

aplikasi ini bisa di didownload di 
https://github.com/messirichard/weather-dicoding.git

menjalankan dengan npm install
setelah itu npm run build dan npm run start

untuk API saya mengambil dari 
https://openweathermap.org/

untuk webpack ada di webpack common saya juga import dengan bootstrap dan bundle img juga

untuk custom element ada di folder src/script/title.js
yang mana saya hanya mengambil title untuk custom element
dan juga ada di main.js di bagian highlow

untuk pemanfaatan ajax fetch ada di folder src/script/index.js
di bagian getResults

harap memasukkan secara manual karena saya tidak memanfaatkan autocomplete di field box
jika diisi 'nama kota maka akan muncul'
contoh surabaya, jakarta, moscow, london, dll

semua sudah responsive
thanks