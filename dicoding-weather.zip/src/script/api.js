const api = {
    key: "5ba445330829d5ec91735c6803775dd7",
    base: "https://api.openweathermap.org/data/2.5/"
}

export { api as default };
